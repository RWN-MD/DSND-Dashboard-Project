from setuptools import setup, find_packages

setup(
    name="employee_events",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pandas", 
        "pytest",
    ],
    description="A Python package for querying and handling employee events data.",
    author="RWN",
    author_email="russellwnordquist@gmail.com",
    url="https://github.com/RWN-MD/DSND-Dashboard-Udacity-project/python-package/employee_events",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
